// ===== Variáveis do packzão (preencher quando o chat 1 definir) =====
const CHECKOUT = 'https://pay.kiwify.com.br/HFUYYsj';
const PRECO = 'R$ 37';
const PRECO_DE = '';                  // vazio: sem de/por
const NOME = 'Kits do Gu · Pack Instagram';
const TOTAL = '459 artes';
const COLECOES = '12';
const VIDEO = '';                     // ex.: 'assets/video/trocar-cor.mp4' (chat 2)
// Frases que dependem de confirmação: false esconde em todo o site
const ACESSO_NA_HORA = true;          // Kiwify libera o acesso automático
const CANVA_GRATIS = true;            // conferido que nenhuma arte usa elemento Pro
const COLECAO_NOVA = true;            // área de membros entrega coleções novas pra quem já comprou
const GARANTIA = false;               // true só depois de confirmar a garantia de 7 dias na Kiwify
const PAGTO = false;                  // true só depois de confirmar Pix/cartão na Kiwify

const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const calmo = matchMedia('(prefers-reduced-motion: reduce)').matches;

if (PRECO) $$('[data-preco]').forEach(e => e.textContent = PRECO);
if (PRECO_DE) $$('[data-de]').forEach(e => e.textContent = PRECO_DE);
if (NOME) $$('[data-nome]').forEach(e => e.textContent = NOME);
$$('[data-total]').forEach(e => { if (!e.querySelector('[data-conta]')) e.textContent = TOTAL; });
$$('[data-total-min]').forEach(e => e.textContent = TOTAL.toLowerCase());
$$('[data-colecoes]').forEach(e => e.textContent = COLECOES);

$$('[data-checkout]').forEach(a => {
  if (CHECKOUT) { a.href = CHECKOUT; a.rel = 'noopener'; }
  a.addEventListener('click', () => { if (window.fbq) fbq('track', 'InitiateCheckout'); });
});

const selos = { acesso: ACESSO_NA_HORA, gratis: CANVA_GRATIS, novas: COLECAO_NOVA };
$$('[data-selo]').forEach(e => { if (!selos[e.dataset.selo]) e.remove(); });
if (GARANTIA) $$('[data-garantia]').forEach(e => e.hidden = false);
if (PAGTO) $$('[data-pagto]').forEach(e => e.hidden = false);

if (VIDEO) {
  const v = $('[data-video]');
  v.hidden = false;
  v.innerHTML = `<video src="${VIDEO}" playsinline muted loop autoplay preload="metadata" style="width:100%;height:100%;object-fit:cover"></video>`;
}

// ===== abertura =====
$$('.hero [data-rise]').forEach((e, i) => e.style.setProperty('--d', i));
requestAnimationFrame(() => requestAnimationFrame(() => $('.hero').classList.add('anim')));

// ===== topo e botão fixo =====
const topo = $('[data-topo]'), fixo = $('.fixo');
addEventListener('scroll', () => topo.classList.toggle('rolou', scrollY > 8), { passive: true });
let heroFora = false, ofertaVisivel = false;
const atualizaFixo = () => fixo.classList.toggle('mostra', heroFora && !ofertaVisivel);
new IntersectionObserver(([e]) => { heroFora = !e.isIntersecting && e.boundingClientRect.top < 0; atualizaFixo(); }).observe($('.hero__acao'));
new IntersectionObserver(([e]) => { ofertaVisivel = e.isIntersecting; atualizaFixo(); }, { threshold: .2 }).observe($('#oferta'));

// ===== revelar no scroll =====
const io = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) { e.target.classList.add('dentro'); io.unobserve(e.target); }
}), { rootMargin: '0px 0px -8% 0px' });
$$('[data-in]').forEach((el, i, all) => {
  const irmaos = all.filter(x => x.parentElement === el.parentElement);
  el.style.transitionDelay = (irmaos.indexOf(el) * 80) + 'ms';
  io.observe(el);
});

// ===== leque da abertura =====
const leque = $('[data-leque]');
const cartas = $$('.leque__arte', leque);
const gira = () => {
  const frente = cartas.find(c => c.dataset.p === '1');
  if (frente && !calmo) { frente.classList.remove('dobra'); void frente.offsetWidth; frente.classList.add('dobra'); }
  setTimeout(() => cartas.forEach(c => c.dataset.p = (+c.dataset.p + 1) % 3), calmo ? 0 : 420);
};
cartas.forEach(c => c.addEventListener('animationend', () => c.classList.remove('dobra')));
let tLeque;
const autoLeque = () => { clearInterval(tLeque); if (!calmo) tLeque = setInterval(gira, 2800); };
leque.addEventListener('click', () => { gira(); autoLeque(); });
setTimeout(autoLeque, 3600);
if (!calmo) {
  let pend = false;
  const abre = () => {
    pend = false;
    const r = leque.getBoundingClientRect();
    const v = (1 - (r.top + r.height / 2) / innerHeight) * 1.6 - .3;
    leque.style.setProperty('--abre', Math.min(1, Math.max(0, v)).toFixed(3));
  };
  addEventListener('scroll', () => { if (!pend) { pend = true; requestAnimationFrame(abre); } }, { passive: true });
}

// ===== tela do celular trocando de arte =====
const tela = $$('[data-tela] img');
let iTela = 0;
if (!calmo) setInterval(() => {
  tela[iTela].classList.remove('on');
  iTela = (iTela + 1) % tela.length;
  tela[iTela].classList.add('on');
}, 2200);

// ===== galeria: duplica pra rolar sem fim =====
$$('[data-trilho]').forEach(t => t.innerHTML += t.innerHTML);

// ===== coleções =====
const palco = $('[data-palco]');
const chips = $$('[data-chips] button');
const mostra = b => {
  chips.forEach(c => c.setAttribute('aria-selected', c === b));
  const img = b.dataset.img;
  palco.innerHTML = img
    ? `<img src="assets/img/${img}.webp" alt="Arte da coleção ${b.textContent}" width="540" height="720">`
    : `<div class="vazio">${b.textContent}<br><small style="font:italic 500 13px Montserrat,sans-serif;color:#5a5856">prévia chegando</small></div>`;
};
let tCol, iCol = 0;
const autoCol = () => { clearInterval(tCol); if (!calmo) tCol = setInterval(() => { iCol = (iCol + 1) % chips.length; mostra(chips[iCol]); }, 2600); };
chips.forEach((b, i) => b.addEventListener('click', () => { iCol = i; mostra(b); autoCol(); }));
new IntersectionObserver(([e]) => e.isIntersecting ? autoCol() : clearInterval(tCol)).observe(palco);

// ===== carrossel do "o que vem" passa sozinho =====
const car = $('[data-carrossel]');
if (car && !calmo) {
  let iCar = 0, tocou = false;
  car.addEventListener('pointerdown', () => tocou = true, { passive: true });
  new IntersectionObserver(([e]) => {
    clearInterval(car._t);
    if (e.isIntersecting) car._t = setInterval(() => {
      if (tocou) return;
      const imgs = car.children; iCar = (iCar + 1) % imgs.length;
      car.scrollTo({ left: imgs[iCar].offsetLeft - car.offsetLeft - 22, behavior: 'smooth' });
    }, 2000);
  }).observe(car);
}

// FAQ: abre um por vez
$$('details').forEach(d => d.addEventListener('toggle', () => {
  if (d.open) $$('details').forEach(o => o !== d && (o.open = false));
}));

// ===== corte da foto (?corte=blob|recorte|capsula) =====
const corte = new URLSearchParams(location.search).get('corte') || (location.hash.match(/corte-(\w+)/) || [])[1];
const aplicaCorte = k => { const c = $('[data-cena]'); c.className = c.className.replace(/corte-\w+/, 'corte-' + k); };
addEventListener('hashchange', () => { const k = (location.hash.match(/corte-(\w+)/) || [])[1]; if (k) aplicaCorte(k); });
if (corte) { const c = $('[data-cena]'); c.className = c.className.replace(/corte-\w+/, 'corte-' + corte); }

// ===== títulos palavra por palavra =====
$$('[data-palavras]').forEach(h => {
  let w = 0;
  const parte = n => {
    if (n.nodeType === 3) {
      const f = document.createDocumentFragment();
      n.textContent.split(/(\s+)/).forEach(t => {
        if (!t) return;
        if (/^\s+$/.test(t)) { f.append(t); return; }
        const s = document.createElement('span'); s.className = 'pal';
        const i = document.createElement('span'); i.textContent = t; i.style.setProperty('--w', w++);
        s.append(i); f.append(s);
      });
      n.replaceWith(f);
    } else if (n.nodeType === 1 && n.tagName === 'EM') {
      const s = document.createElement('span'); s.className = 'pal';
      const i = document.createElement('span'); i.style.setProperty('--w', w++);
      i.append(n.cloneNode(true)); s.append(i); n.replaceWith(s);
    }
  };
  [...h.childNodes].forEach(parte);
});

// ===== números contando =====
const conta = el => {
  const fim = +el.dataset.conta, t0 = performance.now(), dur = 1400;
  const passo = t => {
    const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(fim * e);
    if (p < 1) requestAnimationFrame(passo);
  };
  requestAnimationFrame(passo);
};
if (!calmo) {
  const ioC = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { conta(e.target); ioC.unobserve(e.target); } }), { threshold: .6 });
  $$('[data-conta]').forEach(el => { el.textContent = '0'; ioC.observe(el); });
}

// ===== galeria inclina com a velocidade =====
if (!calmo) {
  const tr = $('.trilhos'); let ultimo = scrollY, sk = 0;
  const loop = () => {
    const v = scrollY - ultimo; ultimo = scrollY;
    sk += (Math.max(-6, Math.min(6, v * .15)) - sk) * .12;
    tr.style.setProperty('--skew', sk.toFixed(2) + 'deg');
    requestAnimationFrame(loop);
  };
  loop();
}
